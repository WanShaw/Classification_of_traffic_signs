最高分模型为四个模型的融合结果；
四个模型的训练细节分别在model?文件中，包括运行环境
所有模型均为DenseNet161；

22125284+王孝+万怀宇+OneFlow.json：最高分模型的预测结果json文件；
bestmodel_predict.py：生成最高分模型预测结果文件；
of_DenseNet.py：模型文件（使用预训练的模型）
submit_example.json：测试集的json文件；
总的来说，运行bestmodel_predict.py即可得到最后的最高分结果