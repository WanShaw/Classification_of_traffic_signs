from of_DenseNet import DenseNet161_pre
import flowvision.transforms as ft
import cv2
import json
import oneflow as of
import glob

pth_paths = glob.glob('0805/161_ls_*')
n = len(pth_paths)
'''
json_paths = glob.glob('0808/*.json')
n2 = len(json_paths)
json_list = []
for json1 in json_paths:
    json_list.append(json1.replace('.json', ''))
print('num_pth', n-n2)
'''
print('num_pth', n)
file = open('submit_example.json')
infos = json.load(file)
annotations = infos['annotations']

size = 224
transforms = ft.Compose([
            ft.ToTensor(),
            # ft.Resize(size=(size, size)),
            ft.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ]
        )

len1 = len(annotations)
print('总数量:', len1)
model = DenseNet161_pre(num_classes=10, pretrained=False)
i = 1
for pth_path in pth_paths:
    '''
    if pth_path in json_list:
        continue
    else:
    '''
    print(i)
    i += 1
    model.load_state_dict(of.load(pth_path))
    model.to('cuda')
    model.eval()
    result = {}
    ann = []

    for temp in annotations:
        imgfile = temp['filename']
        img = cv2.imread(imgfile)
        img = cv2.blur(img, ksize=(9, 9))
        img = transforms(img)
        img = of.reshape(img, (1, 3, size, size))
        img = img.to('cuda')
        with of.no_grad():
            pred = model(img)
        _, indices = of.topk(pred, k=1, dim=1)
        re = indices.item()
        ann.append({'filename': imgfile, 'label': int(re)})

    result['annotations'] = ann
    with open("{}.json".format(pth_path), "w", encoding='utf-8') as f:  # 设置'utf-8'编码
        f.write(json.dumps(result, ensure_ascii=False, indent=4))
